import { MdPersonOff, MdCheckCircle } from "react-icons/md"

const users = [
  { id: 1, name: "Rahul", role: "Technician", status: "Active" },
  { id: 2, name: "Anita", role: "Manager", status: "Inactive" },
  { id: 3, name: "Suresh", role: "Technician", status: "Active" },
]

export default function Users() {
  return (
    <div>
      {/* Page Header */}
      <div className="page-header-row">
        <div>
          <h2>Team Members</h2>
          <p>Manage users and their access</p>
        </div>
      </div>

      {/* Table Card */}
      <div className="card table-card">
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Status</th>
                <th align="right">Action</th>
              </tr>
            </thead>

            <tbody>
              {users.map(user => (
                <tr key={user.id}>
                  <td>
                    <strong>{user.name}</strong>
                  </td>

                  <td>{user.role}</td>

                  <td>
                    <span
                      className={`status ${
                        user.status === "Active" ? "completed" : "pending"
                      }`}
                    >
                      {user.status}
                    </span>
                  </td>

                  <td align="right">
                    {user.status === "Active" ? (
                      <MdPersonOff className="icon-btn delete" />
                    ) : (
                      <MdCheckCircle className="icon-btn edit" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
