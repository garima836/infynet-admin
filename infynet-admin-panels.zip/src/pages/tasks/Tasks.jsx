import "./task-common.css"

import { MdEdit, MdDelete, MdAdd } from "react-icons/md"

const tasks = [
  { id: 1, title: "Install Fiber", assignee: "Technician A", status: "Pending" },
  { id: 2, title: "Router Replacement", assignee: "Technician B", status: "In Progress" },
  { id: 3, title: "Speed Issue Fix", assignee: "Technician C", status: "Completed" },
]

export default function Tasks() {
  return (
    <div>
      {/* Page Header */}
      <div className="page-header-row">
        <div>
          <h2>Tasks</h2>
          <p>Track, assign and manage field tasks</p>
        </div>

        <button className="primary-btn">
          <MdAdd size={18} /> Add Task
        </button>
      </div>

      {/* Table Card */}
      <div className="card table-card">
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Task</th>
                <th>Assigned To</th>
                <th>Status</th>
                <th align="right">Actions</th>
              </tr>
            </thead>

            <tbody>
              {tasks.map(task => (
                <tr key={task.id}>
                  <td>
                    <strong>{task.title}</strong>
                  </td>

                  <td>{task.assignee}</td>

                  <td>
                    <span className={`status ${task.status.replace(" ", "").toLowerCase()}`}>
                      {task.status}
                    </span>
                  </td>

                  <td align="right">
                    <MdEdit className="icon-btn edit" />
                    <MdDelete className="icon-btn delete" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
