import "./task-common.css"

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const taskData = [
  { name: "Pending", value: 34 },
  { name: "In Progress", value: 56 },
  { name: "Completed", value: 38 },
]

const COLORS = ["#facc15", "#38bdf8", "#22c55e"]

const kpis = [
  { label: "Total Tasks", value: 128 },
  { label: "Completion Rate", value: "30%" },
  { label: "Avg Resolution", value: "2.4 Days" },
  { label: "Active Technicians", value: 12 },
]

export default function Reports() {
  return (
    <div>
      {/* Page Header */}
      <div className="page-header-row">
        <div>
          <h2>Reports & Analytics</h2>
          <p>Operational insights and performance metrics</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        {kpis.map(item => (
          <div key={item.label} className="card kpi-card">
            <p>{item.label}</p>
            <h2>{item.value}</h2>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="charts-grid">
        <div className="card">
          <h4>Task Distribution</h4>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={taskData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h4>Completion Ratio</h4>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={taskData}
                dataKey="value"
                innerRadius={70}
                paddingAngle={4}
              >
                {taskData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Insights */}
      <div className="card insights-card">
        <h4>Key Insights</h4>
        <ul>
          <li>🔹 Most tasks are currently in progress, indicating high workload</li>
          <li>🔹 Completion rate can improve with better technician allocation</li>
          <li>🔹 Pending tasks peak during weekends</li>
        </ul>
      </div>
    </div>
  )
}
