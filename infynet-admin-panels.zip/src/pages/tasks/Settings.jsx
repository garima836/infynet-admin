export default function Settings() {
  return (
    <div className="card" style={{ maxWidth: 500 }}>
      <h3 style={{ marginBottom: 20 }}>Admin Settings</h3>

      <input placeholder="Admin Name" style={input} />
      <input placeholder="Email" style={input} />

      <button className="btn-primary">Save</button>
    </div>
  )
}

const input = {
  width: "100%",
  padding: 12,
  marginBottom: 12,
  borderRadius: 8,
  border: "1px solid #e5e7eb",
}
