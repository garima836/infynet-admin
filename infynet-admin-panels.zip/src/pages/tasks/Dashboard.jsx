export default function Dashboard() {
  return (
    <>
      <div className="page-header">
        <h2>Task Overview</h2>
        <p>Track progress and workforce efficiency</p>
      </div>

      <div className="grid grid-3">
        <div className="card stat">
          <span className="icon blue">📋</span>
          <div>
            <p>Total Tasks</p>
            <h3>128</h3>
          </div>
        </div>

        <div className="card stat">
          <span className="icon orange">⏳</span>
          <div>
            <p>In Progress</p>
            <h3>56</h3>
          </div>
        </div>

        <div className="card stat">
          <span className="icon green">✅</span>
          <div>
            <p>Completed</p>
            <h3>38</h3>
          </div>
        </div>
      </div>
    </>
  )
}
