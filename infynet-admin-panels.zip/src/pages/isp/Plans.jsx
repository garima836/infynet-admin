import "./isp-common.css"

export default function Plans() {
  return (
    <div className="page">
      <h2 className="page-title">Available Plans</h2>

      <div className="grid stats-grid">
        <PlanCard name="Basic" speed="100 Mbps" price="₹499" />
        <PlanCard name="Standard" speed="300 Mbps" price="₹799" />
        <PlanCard name="Premium" speed="1 Gbps" price="₹1,499" />
      </div>
    </div>
  )
}

function PlanCard({ name, speed, price }) {
  return (
    <div className="card">
      <h3>{name}</h3>
      <p className="stat-title">{speed}</p>
      <h3 className="stat-value">{price} / month</h3>
    </div>
  )
}
