import { Routes, Route, Navigate } from "react-router-dom"
import Login from "./pages/auth/Login"
import ISPLayout from "./layouts/ISPLayout"
import TaskLayout from "./layouts/TaskLayout"

export default function App() {
  return (
    <Routes>
      {/* Login */}
      <Route path="/login" element={<Login />} />

      {/* Role-based panels */}
      <Route path="/isp/*" element={<ISPLayout />} />
      <Route path="/tasks/*" element={<TaskLayout />} />

      {/* Default redirect */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  )
}
