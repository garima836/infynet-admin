import "./Topbar.css"

export default function Topbar({ title }) {
  return (
    <header className="topbar">
      <div>
        <h3>{title}</h3>
        <p className="subtitle">Welcome back, Admin</p>
      </div>

      <div className="profile">
        <div className="avatar">A</div>
        <span>Admin</span>
      </div>
    </header>
  )
}

