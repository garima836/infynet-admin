import {
  MdDashboard,
  MdAssignment,
  MdPeople,
  MdBarChart,
  MdSettings,
} from "react-icons/md"
import "./Sidebar.css"

export default function TaskSidebar({ activePage, setPage }) {
  const menu = [
    { id: "dashboard", label: "Dashboard", icon: <MdDashboard /> },
    { id: "tasks", label: "Tasks", icon: <MdAssignment /> },
    { id: "users", label: "Users", icon: <MdPeople /> },
    { id: "reports", label: "Reports", icon: <MdBarChart /> },
    { id: "settings", label: "Settings", icon: <MdSettings /> },
  ]

  return (
    <aside className="sidebar">
      <img
        src="https://res.cloudinary.com/dzp296lmx/image/upload/v1769532616/Infynet_TM_Logo_nvjuqw.png"
        alt="Infynet"
        className="logo"
      />

      {menu.map(item => (
        <div
          key={item.id}
          className={`sidebar-item ${activePage === item.id ? "active" : ""}`}
          onClick={() => setPage(item.id)}
        >
          {item.icon}
          <span>{item.label}</span>
        </div>
      ))}
    </aside>
  )
}
