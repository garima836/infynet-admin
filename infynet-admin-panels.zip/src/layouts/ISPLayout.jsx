import { useState } from "react"
import ISPSidebar from "../components/Sidebar/ISPSidebar"
import Topbar from "../components/Topbar/Topbar"

import Dashboard from "../pages/isp/Dashboard"
import Providers from "../pages/isp/Providers"
import Plans from "../pages/isp/Plans"
import Analytics from "../pages/isp/Analytics"
import Users from "../pages/isp/Users"
import Settings from "../pages/isp/Settings"

export default function ISPLayout() {
  const [page, setPage] = useState("dashboard")

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <ISPSidebar activePage={page} setPage={setPage} />

      <main style={{ flex: 1, padding: 20 }}>
        <Topbar title="ISP Admin Panel" />

        {page === "dashboard" && <Dashboard />}
        {page === "providers" && <Providers />}
        {page === "plans" && <Plans />}
        {page === "analytics" && <Analytics />}
        {page === "users" && <Users />}
        {page === "settings" && <Settings />}
      </main>
    </div>
  )
}
